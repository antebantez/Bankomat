public class Kunder {
    public String användare;
    public int personalId;
    public double saldo;

    Kunder(String användare, int personalId, double saldo){
        this.användare = användare;
        this.personalId = personalId;
        this.saldo = saldo;
    }
    static Kunder kund1 = new Kunder("Anton Olsson", 12345, 0);

    static Kunder kund2 = new Kunder("Nenad", 54321,0);


}
